"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const buffer_1 = require("buffer");
const tweeter_shared_1 = require("tweeter-shared");
class UserService {
    async login(alias, password) {
        // TODO: Replace with the result of calling the server
        return this.getFakeData("Invalid alias or password");
    }
    ;
    async register(firstName, lastName, alias, password, userImageBytes, imageFileExtension) {
        // Not neded now, but will be needed when you make the request to the server in milestone 3
        const imageStringBase64 = buffer_1.Buffer.from(userImageBytes).toString("base64");
        // TODO: Replace with the result of calling the server
        return this.getFakeData("Invalid registration");
    }
    ;
    async getUser(token, alias) {
        // TODO: Replace with the result of calling server
        //return FakeData.instance.findUserByAlias(alias);
        const user = tweeter_shared_1.FakeData.instance.findUserByAlias(alias);
        return user.dto;
    }
    ;
    async logout(token) {
        // Pause so we can see the logging out message. Delete when the call to the server is implemented.
        await new Promise((res) => setTimeout(res, 1000));
    }
    ;
    async getFakeData(message) {
        // TODO: Replace with the result of calling the server
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error(message);
        }
        return [user.dto, tweeter_shared_1.FakeData.instance.authToken];
    }
}
exports.UserService = UserService;
